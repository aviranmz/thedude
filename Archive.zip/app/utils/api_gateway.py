import logging
from app.services.hotellook import search_hotels
from app.services.flightlook import search_flights
from app.services.searchcars import search_cars

async def call_trip_api(info):
    reply = []
    logging.info(f"Calling trip API with info: {info}")
    if "flight" in info.get("type", []):
        result = await search_flights(info)
        reply.append("✈️ Flights:\n" + result)

    if "hotel" in info.get("type", []):
        result = await search_hotels(info)
        reply.append("🏨 Hotels:\n" + result)

    if "car" in info.get("type", []):
        result = await search_cars(info)
        reply.append("🚗 Cars:\n" + result)

    if "weather" in info.get("type", []):
        reply.append(f"🌤️ Weather in {info['destination']}: Sunny 25–30°C")

    if "esim" in info.get("type", []):
        reply.append(f"📶 eSIM for {info['destination']}: $15/10GB")

    return {"formatted_reply": "\n\n".join(reply)}
