import json
from .llm_provider import call_llm_agent
from datetime import datetime

async def extract_trip_info(message, prefs):
    LLM_TEMPLATE = """
    You are Dude, a friendly AI travel assistant in PLANNING MODE.

    User Message: {message}
    User Preferences: {prefs}
    Time: {now}

    Extract structured information:
    - Destination
    - Dates
    - Trip type (flight, hotel, car)
    - Budget
    Return JSON with:
    {{
      "complete": true/false,
      "type": ["hotel", "flight", "car"],
      "destination": "...",
      "dates": {{"start": "...", "end": "..."}},
      "updated_prefs": {{}},
      "follow_up": "Ask this if data is missing"
    }}
    """

    prompt = LLM_TEMPLATE.format(message=message, prefs=str(prefs), now=datetime.now().isoformat())
    raw_response = await call_llm_agent(prompt, prefs, tools=["hotel", "flight", "car"], mode="plan")

    try:
        return json.loads(raw_response)
    except json.JSONDecodeError:
        return {
            "complete": False,
            "type": [],
            "destination": None,
            "dates": {},
            "updated_prefs": {},
            "follow_up": "⚠️ Could not parse LLM response."
        }